package com.program;
// Created by 21343023_Fachri Rizal
public class tugas1b {
    public static void main(String[] args) {
        int nama=0;

        while (nama<10){
            System.out.println("Fachri");
            nama++;
        }
    }
}
