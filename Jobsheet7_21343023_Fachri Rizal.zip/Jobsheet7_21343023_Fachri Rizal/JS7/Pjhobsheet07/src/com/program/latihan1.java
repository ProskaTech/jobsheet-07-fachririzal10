package com.program;
// Created by 21343023_Fachri Rizal
// pernyataan for
public class latihan1 {
    public static void main(String[] args) {
        int bilangan;
        for (bilangan=20; bilangan<=100; bilangan+=10)
        System.out.println(bilangan);

    }
}
