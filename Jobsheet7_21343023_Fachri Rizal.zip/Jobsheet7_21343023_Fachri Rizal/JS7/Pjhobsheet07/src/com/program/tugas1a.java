package com.program;
// Created by 21343023_Fachri Rizal
public class tugas1a {
    public static void main(String[] args) {

        int nama;
        for (nama=1; nama<=10; nama++){
        System.out.println("Fachri");
         }   
    }
}
