package com.program;
// Created by 21343023_Fachri Rizal
public class tugas1c {
    public static void main(String[] args) {
        int nama=0;

        do{
            System.out.println("Fachri");
            nama++;
        }
        while (nama<10);

    }
}
