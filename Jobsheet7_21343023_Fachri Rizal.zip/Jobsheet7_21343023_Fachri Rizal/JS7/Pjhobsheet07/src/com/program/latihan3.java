package com.program;
// Created by 21343023_Fachri Rizal
// pernyataan for
public class latihan3 {
    public static void main(String[] args) {
     
    int bil;
    for (bil=0; bil<=10; bil++)
    System.out.println(bil);

    }
}
