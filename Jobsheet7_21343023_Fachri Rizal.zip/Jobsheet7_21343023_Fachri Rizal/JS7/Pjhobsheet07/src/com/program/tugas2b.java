package com.program;
// Created by 21343023_Fachri Rizal
public class tugas2b {
    public static void main(String[] args) {
        int angka=20;

        while (angka>=1){
            System.out.println(angka);
            angka--;
        }
    }
}
